Slide In Panel
=========

A CSS3 and JavaScript powered slide-in panel, to quickly show side content, notifications or profile information.

[Article on CodyHouse](https://codyhouse.co/gem/css-slide-in-panel/)

[Demo](https://codyhouse.co/demo/slide-in-panel/)
 
[Terms](https://codyhouse.co/terms/)